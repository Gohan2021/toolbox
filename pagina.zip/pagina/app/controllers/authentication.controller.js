import bcryptjs from "bcryptjs";

const usuarios = [{
    user:"a",
    email:"a@a.com",
    password:"2a$05$gk02sPE/XJ.LkqOeiBMEyOFAJWzadklV42nbvjt3mu3ty13z5bEYa"
}];

async function login(req, res) {
    // Lógica de inicio de sesión
}

async function registerAliado(req, res) {
    const { userNameAliado,secondNameAliado,userIDAliado,emailAliado,passwordAliado } = req.body;

    if (!userNameAliado || !secondNameAliado || !userIDAliado || !emailAliado || !passwordAliado) {
        return res.status(400).send({ status: "Error", message: "Los campos están incompletos" });
    }

    const usuarioRevisar = usuarios.find(usuario => usuario.user === userNameAliado);
    if (usuarioRevisar) {
        return res.status(400).send({ status: "Error", message: "Este usuario ya existe" });
    }

    const salt = await bcryptjs.genSalt(5);
    const hashPassword = await bcryptjs.hash(passwordAliado, salt); // Ensure this is passwordAliado, not password
    const nuevoUsuario = {
        user: userNameAliado,
        secondNameAliado: secondNameAliado,
        userIDAliado: userIDAliado,
        email: emailAliado, 
        password: hashPassword
    };

    usuarios.push(nuevoUsuario);
    console.log(usuarios);
    return res.status(201).send({ status: "Success", message: `Nuevo aliado ${nuevoUsuario.user} registrado exitosamente`, redirect: "/form" });
}

async function registerCliente(req, res) {
    const { userNameCliente,secondNameAliado, emailCliente, passwordCliente } = req.body;

    if (!userNameCliente || !emailCliente || !passwordCliente) {
        return res.status(400).send({ status: "Error", message: "Los campos están incompletos" });
    }
    const usuarioRevisar = usuarios.find(usuario => usuario.user === userNameAliado);
    if(usuarioRevisar){
        return res.status(400).send({ status: "Error", message: "Este usuario ya existe" });
    }
    // Guardar el cliente en la base de datos o array
    usuarios.push({ user: userNameCliente, email: emailCliente, password: passwordCliente, role: "cliente" });
    return res.status(200).send({ status: "Success", message: "Cliente registrado exitosamente" });
}

export const methods = {
    login,
    registerAliado,
    registerCliente
};